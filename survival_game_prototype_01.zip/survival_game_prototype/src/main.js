import * as THREE from 'three';

const mount = document.querySelector('#game');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x879477);
scene.fog = new THREE.Fog(0x879477, 18, 48);

const camera = new THREE.OrthographicCamera(-12, 12, 12, -12, 0.1, 100);
camera.position.set(10, 16, 10);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
mount.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xe6edda, 0x4b5740, 2.0));
const sun = new THREE.DirectionalLight(0xffefcf, 2.2);
sun.position.set(-8, 18, 10);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
scene.add(sun);

const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(100, 100),
  new THREE.MeshStandardMaterial({ color: 0x667b55, roughness: 1 })
);
ground.rotation.x = -Math.PI / 2;
ground.receiveShadow = true;
scene.add(ground);

// Subtle patches make the ground feel less like a blank test plane.
for (let i = 0; i < 90; i++) {
  const patch = new THREE.Mesh(
    new THREE.CircleGeometry(0.25 + Math.random() * 0.8, 7),
    new THREE.MeshStandardMaterial({ color: Math.random() > .5 ? 0x71845c : 0x596e4d, roughness: 1 })
  );
  patch.rotation.x = -Math.PI / 2;
  patch.position.set((Math.random() - .5) * 42, 0.012, (Math.random() - .5) * 42);
  scene.add(patch);
}

const player = new THREE.Group();
const body = new THREE.Mesh(
  new THREE.CapsuleGeometry(0.38, 0.55, 4, 8),
  new THREE.MeshStandardMaterial({ color: 0x3d5961, roughness: .85 })
);
body.position.y = 0.78;
body.castShadow = true;
player.add(body);
const head = new THREE.Mesh(new THREE.SphereGeometry(.25, 12, 10), new THREE.MeshStandardMaterial({ color: 0xc89b75 }));
head.position.set(0, 1.42, 0);
head.castShadow = true;
player.add(head);
const pack = new THREE.Mesh(new THREE.BoxGeometry(.38,.48,.2), new THREE.MeshStandardMaterial({color:0x594a32}));
pack.position.set(0,.83,-.34);
player.add(pack);
player.position.set(0,0,0);
scene.add(player);

const resources = [];
function addTree(x,z) {
  const g = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.16,.22,1.2,7), new THREE.MeshStandardMaterial({color:0x65472f}));
  trunk.position.y=.6; trunk.castShadow=true; g.add(trunk);
  const crown = new THREE.Mesh(new THREE.ConeGeometry(.85,2.1,7), new THREE.MeshStandardMaterial({color:0x294d35, roughness:1}));
  crown.position.y=2; crown.castShadow=true; g.add(crown);
  g.position.set(x,0,z); scene.add(g);
  resources.push({type:'wood', object:g, x,z, active:true});
}
function addRock(x,z) {
  const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(.55,0), new THREE.MeshStandardMaterial({color:0x85877d, roughness:1}));
  rock.position.set(x,.35,z); rock.scale.set(1.2,.75,1); rock.castShadow=true; scene.add(rock);
  resources.push({type:'stone', object:rock, x,z, active:true});
}
for (const [x,z] of [[-5,-4],[-7,1],[5,-5],[7,2],[-3,7],[8,7],[1,-8]]) addTree(x,z);
for (const [x,z] of [[-4,3],[4,2],[6,-1],[-8,-5],[2,8]]) addRock(x,z);

// Simple distant boundary props.
for (let i=0;i<36;i++) {
  const a = i/36*Math.PI*2, r=18;
  const bush = new THREE.Mesh(new THREE.SphereGeometry(.65,7,6), new THREE.MeshStandardMaterial({color:0x3c593b}));
  bush.position.set(Math.cos(a)*r,.35,Math.sin(a)*r);
  bush.scale.y=.7; bush.castShadow=true; scene.add(bush);
}

let wood = 0, stone = 0;
const woodEl = document.querySelector('#wood');
const stoneEl = document.querySelector('#stone');
const toast = document.querySelector('#toast');
let toastTimer;
function notify(msg) {
  toast.textContent = msg; toast.classList.add('show');
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>toast.classList.remove('show'),1500);
}

const input = {x:0,z:0};
const joystick = document.querySelector('#joystick');
const stick = document.querySelector('#stick');
let activePointer = null;
function setStick(e) {
  const r=joystick.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2;
  let dx=e.clientX-cx, dy=e.clientY-cy;
  const max=38, len=Math.hypot(dx,dy);
  if(len>max){dx=dx/len*max;dy=dy/len*max;}
  stick.style.transform=`translate(${dx}px,${dy}px)`;
  input.x=dx/max; input.z=dy/max;
}
joystick.addEventListener('pointerdown', e=>{activePointer=e.pointerId;joystick.setPointerCapture(activePointer);setStick(e);});
joystick.addEventListener('pointermove', e=>{if(e.pointerId===activePointer)setStick(e);});
function releaseStick(){activePointer=null;input.x=0;input.z=0;stick.style.transform='translate(0,0)';}
joystick.addEventListener('pointerup',releaseStick);
joystick.addEventListener('pointercancel',releaseStick);

const keys={};
addEventListener('keydown',e=>keys[e.key.toLowerCase()]=true);
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);

function nearestResource() {
  return resources.filter(r=>r.active).sort((a,b)=>distance(a)-distance(b))[0];
}
function distance(r){return Math.hypot(player.position.x-r.x,player.position.z-r.z);}
document.querySelector('#collect').addEventListener('click',()=>{
  const r=nearestResource();
  if(!r || distance(r)>2.4){notify('Подойди ближе к дереву или камню');return;}
  r.active=false; scene.remove(r.object);
  if(r.type==='wood'){wood+=3;woodEl.textContent=wood;notify('+3 дерева');}
  else {stone+=2;stoneEl.textContent=stone;notify('+2 камня');}
});
document.querySelector('#attack').addEventListener('click',()=>notify('Боевая система появится на следующем этапе'));

const clock=new THREE.Clock();
function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.04);
  let x=input.x, z=input.z;
  if(keys.w||keys.arrowup)z-=1;
  if(keys.s||keys.arrowdown)z+=1;
  if(keys.a||keys.arrowleft)x-=1;
  if(keys.d||keys.arrowright)x+=1;
  const len=Math.hypot(x,z);
  if(len>.05){
    x/=Math.max(1,len); z/=Math.max(1,len);
    player.position.x+=x*4.2*dt;
    player.position.z+=z*4.2*dt;
    player.rotation.y=Math.atan2(x,z);
  }
  player.position.x=THREE.MathUtils.clamp(player.position.x,-16,16);
  player.position.z=THREE.MathUtils.clamp(player.position.z,-16,16);
  camera.position.x=player.position.x+10;
  camera.position.z=player.position.z+10;
  camera.lookAt(player.position.x,0,player.position.z);
  renderer.render(scene,camera);
}
animate();

function resize(){
  const aspect=innerWidth/innerHeight, size=12;
  camera.left=-size*aspect/1.5; camera.right=size*aspect/1.5;
  camera.top=size; camera.bottom=-size;
  camera.updateProjectionMatrix(); renderer.setSize(innerWidth,innerHeight);
}
addEventListener('resize',resize);
resize();
